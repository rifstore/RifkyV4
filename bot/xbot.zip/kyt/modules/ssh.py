from kyt import *
import subprocess
import time
import datetime as DT
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    async def create_ssh_(event):
        async with bot.conversation(chat) as user:
            await event.respond("Username : ")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        async with bot.conversation(chat) as pw:
            await event.respond("Password : ")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text

        async with bot.conversation(chat) as ip:
            await event.respond("Limit Ip : ")
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text

        async with bot.conversation(chat) as exp:
            await event.respond("Choose Expired Day", buttons=[
                [Button.inline("3 Day", "3"), Button.inline("7 Day", "7")],
                [Button.inline("30 Day", "30"), Button.inline("60 Day", "60")]
            ])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")

        await event.edit("Processing.")
        await event.edit("Processing..")
        await event.edit("Processing...")
        await event.edit("Processing....")
        time.sleep(3)
        await event.edit("`Processing Create Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(3)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(2)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        time.sleep(1)
        await event.edit("`Wait.. Setting up an Account`")

        cmd = f'printf "%s\n" "{user}" "{pw}" "{ip}" "{exp}" | addssh-bot'
        try:
            output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode()
        except subprocess.CalledProcessError as e:
            output = e.output.decode()

        if "Username sudah terpakai" in output:
            await event.respond("Username sudah terpakai.")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msgx = f"""
			`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
			"""
            msg = f"""
`⚪══════════════════⚪`
 Create SSH Account Success
`⚪══════════════════⚪`
 Terimakasih telah berlangganan
 di store kami..!!
 Harap gunakan dengan bijak
 Happy surfing..!!
`⚪══════════════════⚪`
`✦Subdomain :` `{DOMAIN}`
`✦Username  :` `{user.strip()}`
`✦Passwd    :` `{pw.strip()}`
`✦Max Login :` `{ip.strip()} User`
`⚪══════════════════⚪`
`✦Expired {later}`
`⚪══════════════════⚪`
`✦Port Ws   :` `80, 8080`
`✦Drobear   :` `443, 109, 143`
`✦Badvpn    :` `7100 - 7300`
`✦Port Ssl  :` `443, 80, 22`
`⚪══════════════════⚪`
"""
        await event.respond(msg)
        await event.respond(msgx)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_ssh_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)



@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'bot-member-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)



@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		ip = "1000"
		quota = "1000"
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{exp}"| bot-trial'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			msgx = f"""
			`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
			"""
			msg = f"""
`⚪══════════════════⚪`
 Create SSH Account Success
`⚪══════════════════⚪`
 Terimakasih telah berlangganan
 di store kami..!!
 Harap gunakan dengan bijak
 Happy surfing..!!
`⚪══════════════════⚪`
`✦Subdomain :` `{DOMAIN}`
`✦Username  :` `{user.strip()}`
`✦Passwd    :` `{pw.strip()}`
`✦Max Login :` `Unlimited`
`⚪══════════════════⚪`
`✦Expired {exp} Minutes`
`⚪══════════════════⚪`
`✦Port Ws   :` `80, 8080`
`✦Drobear   :` `443, 109, 143`
`✦Badvpn    :` `7100 - 7300`
`✦Port Ssl  :` `443, 80, 22`
`⚪══════════════════⚪`
"""
			await event.respond(msg)
			await event.respond(msgx)

	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline("TRIAL SSH","trial-ssh"),
Button.inline("CREATE SSH","create-ssh")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█

━━━━━━━━━━━━━━━━━━━━━━ 
MENU SSH OVPN
━━━━━━━━━━━━━━━━━━━━━━
`✦ Service :` `SSH OVPN`
`✦ Domain  :` `{DOMAIN}`
`✦ ISP     :` `{z["isp"]}`
`✦ Region  :` `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)